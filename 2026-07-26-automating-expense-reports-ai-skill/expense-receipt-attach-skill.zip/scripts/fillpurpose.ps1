param(
  [Parameter(Mandatory=$true)][string]$Amt,   # e.g. 19.95
  [Parameter(Mandatory=$true)][string]$Text
)
$ErrorActionPreference='Stop'
$tmp=$env:TEMP
$FO=$env:CDP_FO
if(-not $FO){ $FO=(Invoke-RestMethod http://localhost:9222/json/list | Where-Object {$_.type -eq 'page' -and $_.url -match 'operations\.dynamics\.com'} | Select-Object -First 1).id }
if(-not $FO){ throw 'F&O tab not found on CDP :9222 (open the expense report in the CDP-enabled Edge)' }
function E($js){ node "$tmp\cdp.js" $FO eval $js }
function WaitClear(){ for($i=0;$i -lt 12;$i++){ Start-Sleep -Seconds 3; $b=E "(()=>{const b=document.getElementById('ShellBlockingDiv');return b?(b.offsetParent!==null?'B':'C'):'C';})()"; if($b -match 'C'){ return $true } } return $false }

$INST=(E "(()=>{const el=document.querySelector('[id*=ReceiptsAttached_Grid]');return el?el.id.match(/Grid_(\d+)_/)[1]:'none';})()").Trim('"')
$slot=(E "(()=>{const inst='$INST';for(let r=0;r<=30;r++){const a=document.getElementById('AmountCurrWithCurrencyCode_Grid_'+inst+'_0_'+r+'_input');if(a&&a.value.indexOf('$Amt')===0)return ''+r;}return 'nf';})()").Trim('"')
if($slot -eq 'nf'){ Write-Output "RESULT=slot_notfound"; exit 1 }
E "(()=>{const e=document.getElementById('AmountCurrWithCurrencyCode_Grid_${INST}_0_${slot}_input');e.scrollIntoView({block:'center'});e.click();return 's';})()" | Out-Null
WaitClear | Out-Null
$cov=(E "(()=>{const t=document.querySelector('textarea[id\$=AdditionalInformation_textArea]');if(!t)return 'no-ta';const r=t.getBoundingClientRect();const top=document.elementFromPoint(r.left+r.width/2,r.top+r.height/2);return (top===t)?'ok':'covered';})()").Trim('"')
if($cov -ne 'ok'){ Write-Output "RESULT=textarea_$cov"; exit 1 }
node "$tmp\cdp.js" $FO type "textarea[id`$=AdditionalInformation_textArea]" "$Text" | Out-Null
Start-Sleep -Seconds 1
$val=(E "(()=>{const t=document.querySelector('textarea[id\$=AdditionalInformation_textArea]');return t?t.value:'nf';})()").Trim('"')
node "$tmp\cdp.js" $FO press Tab | Out-Null
Start-Sleep -Seconds 2
node "$tmp\cdp.js" $FO clickel "button[id`$=CommandButtonNext]" | Out-Null
Start-Sleep -Seconds 4
WaitClear | Out-Null
Write-Output "RESULT=filled slot=$slot val=[$val]"
