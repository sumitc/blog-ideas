param(
  [Parameter(Mandatory=$true)][string]$Amt,      # e.g. 8.40
  [string]$DatePick = "",                          # optional: substring to disambiguate result (e.g. "Wed" or subject day)
  [Parameter(Mandatory=$true)][string]$OutPdf      # full path to output pdf
)
$ErrorActionPreference='Stop'
$OL=$env:CDP_OL
if(-not $OL){ $OL=(Invoke-RestMethod http://localhost:9222/json/list | Where-Object {$_.type -eq 'page' -and $_.url -match 'outlook\.office'} | Select-Object -First 1).id }
if(-not $OL){ throw 'Outlook tab not found on CDP :9222 (open Outlook web in the CDP-enabled Edge)' }
cd $env:TEMP

function Eval($js){ return (node cdp.js $OL eval $js) }

# 1. search
node cdp.js $OL type "#topSearchInput" "Uber $Amt" | Out-Null
Start-Sleep -Milliseconds 600
node cdp.js $OL press Enter | Out-Null
Start-Sleep -Seconds 5

# 2. list Uber results with their date labels
$listJs = @'
(()=>{const r=[...document.querySelectorAll('[role=option]')].filter(e=>/Uber Receipts/i.test(e.getAttribute('aria-label')||e.innerText||''));return JSON.stringify(r.map((e,i)=>({i,al:(e.getAttribute('aria-label')||'').slice(0,120)})));})()
'@
$listRaw = Eval $listJs
$listRaw = $listRaw.Trim('"').Replace('\"','"')
Write-Output "RESULTS=$listRaw"

# 3. choose index: if DatePick given, find first result whose al contains it, else 0
$idx = 0
if($DatePick -ne ""){
  $arr = $listRaw | ConvertFrom-Json
  $match = $arr | Where-Object { $_.al -match [regex]::Escape($DatePick) } | Select-Object -First 1
  if($match){ $idx = $match.i } else { Write-Output "WARN: DatePick '$DatePick' not found, using 0" }
}
Write-Output "CHOSE idx=$idx"

# 4. click chosen result
$clickJs = @"
(()=>{const r=[...document.querySelectorAll('[role=option]')].filter(e=>/Uber Receipts/i.test(e.getAttribute('aria-label')||e.innerText||''));if(!r[$idx])return 'NOIDX';r[$idx].click();return 'clicked '+(r[$idx].getAttribute('aria-label')||'').slice(0,60);})()
"@
Write-Output (Eval $clickJs)
Start-Sleep -Seconds 4

# 5. extract body (find current Message body container)
$bodyJs = @'
(()=>{const el=document.querySelector('[id^=UniqueMessageBody]');if(!el)return 'NONE';return btoa(unescape(encodeURIComponent(el.innerHTML)));})()
'@
$b64 = (Eval $bodyJs).Trim('"')
if($b64 -eq 'NONE'){ Write-Output "FAIL_body"; exit 1 }
$html = [System.Text.Encoding]::UTF8.GetString([System.Convert]::FromBase64String($b64))
if($html -notmatch [regex]::Escape($Amt)){ Write-Output "FAIL_amt_not_in_body"; exit 1 }
$doc = "<!doctype html><html><head><meta charset='utf-8'><style>body{font-family:Arial,Helvetica,sans-serif;margin:20px;}</style></head><body>$html</body></html>"
$outHtml = [System.IO.Path]::ChangeExtension($OutPdf,'html')
[System.IO.File]::WriteAllText($outHtml,$doc,[System.Text.UTF8Encoding]::new($false))
node htmlpdf.js $outHtml $OutPdf
Write-Output "DONE $OutPdf"
