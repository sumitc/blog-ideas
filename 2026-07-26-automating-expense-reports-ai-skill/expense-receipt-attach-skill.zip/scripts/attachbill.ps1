param(
  [Parameter(Mandatory=$true)][int]$Row,
  [Parameter(Mandatory=$true)][string]$Pdf,
  [Parameter(Mandatory=$true)][string]$AmtTag,  # e.g. 13.84
  [string]$ExpectAmt = ''
)
$ErrorActionPreference='Stop'
$tmp=$env:TEMP
$FO=$env:CDP_FO
if(-not $FO){ $FO=(Invoke-RestMethod http://localhost:9222/json/list | Where-Object {$_.type -eq 'page' -and $_.url -match 'operations\.dynamics\.com'} | Select-Object -First 1).id }
if(-not $FO){ throw 'F&O tab not found on CDP :9222 (open the expense report in the CDP-enabled Edge)' }
function E($js){ node "$tmp\cdp.js" $FO eval $js }
$INST = (E "(()=>{const el=document.querySelector('[id*=ReceiptsAttached_Grid]');return el?el.id.match(/Grid_(\d+)_/)[1]:'168';})()").Trim('"')
Write-Output "INST=$INST"
$GQ = "(()=>{const g=document.getElementById('TrvExpTrans_ReceiptsAttached_Grid_${INST}_0_${Row}_input');return g?g.value:'??';})()"

# 0. already attached?
if((E $GQ) -match 'Yes'){ Write-Output "RESULT=AlreadyYes"; exit 0 }

# 1. close any stray flyout
if((E "(()=>!!document.querySelector('button[id`$=OkButtonAddNewTabPage]'))()") -match 'true'){
  node "$tmp\cdp.js" $FO clickel "button[id`$=CloseButtonAddNewTabPage]" | Out-Null; Start-Sleep -Seconds 2
}

# 2. select row + verify aria-selected == Row (SAFETY)
$sel=$false
for($t=0;$t -lt 4;$t++){
  E "(()=>{const e=document.getElementById('TrvExpTrans_AmountMST_Grid_${INST}_0_${Row}_input');e.scrollIntoView({block:'center'});e.focus();e.click();return 'c';})()" | Out-Null
  Start-Sleep -Seconds 2
  $a = E "(()=>{const rows=[...document.querySelectorAll('[id^=TrvExpTrans_AmountMST_Grid_${INST}_0_][id`$=_input]')];let act='none';rows.forEach(r=>{const m=r.id.match(/_0_(\d+)_input/);const tr=r.closest('[role=row],tr,[class*=row]');if(tr&&tr.getAttribute('aria-selected')==='true')act=m[1];});return act;})()"
  if($a -match "^`"?$Row`"?$"){ $sel=$true; break }
}
if(-not $sel){ Write-Output "RESULT=FAIL_select(active=$a)"; exit 1 }

# amount guard
if($ExpectAmt -ne ''){
  $slotAmt = (E "(()=>{const e=document.getElementById('AmountCurrWithCurrencyCode_Grid_${INST}_0_${Row}_input');return e?e.value:'??';})()").Trim('"')
  if($slotAmt.IndexOf($ExpectAmt) -ne 0){ Write-Output "RESULT=FAIL_amountmismatch(slot=$slotAmt expect=$ExpectAmt)"; exit 1 }
}

# 3. open Actions -> Attach receipt, retry until Browse button appears
$opened=$false
for($t=0;$t -lt 4 -and -not $opened;$t++){
  node "$tmp\cdp.js" $FO clickel "button[id`$=CardBottomMenuFormMenuButtonControl_button]" | Out-Null
  Start-Sleep -Seconds 2
  node "$tmp\cdp.js" $FO clickel "button[id`$=AttachReceiptToExpense]" | Out-Null
  Start-Sleep -Seconds 3
  if((E "(()=>!!document.querySelector('button[id`$=UploadControlBrowseButton]'))()") -match 'true'){ $opened=$true; break }
}
if(-not $opened){ Write-Output "RESULT=FAIL_openflyout"; exit 1 }

# 4. browse (file chooser interception)
$b = node "$tmp\cdp.js" $FO browse "button[id`$=UploadControlBrowseButton]" "$Pdf"
if($b -notmatch 'BROWSED'){ node "$tmp\cdp.js" $FO clickel "button[id`$=CloseButtonAddNewTabPage]" | Out-Null; Write-Output "RESULT=FAIL_browse($b)"; exit 1 }
Start-Sleep -Seconds 2

# verify filename field set
$fn = E "(()=>{const v=[...document.querySelectorAll('input')].map(i=>i.value||'').filter(x=>/${AmtTag}/.test(x));return v.length?'set':'noname';})()"

# 5. TRUSTED Upload click; confirm it registered (Upload btn -> disabled), re-click if missed
Start-Sleep -Seconds 4
$registered=$false
for($c=0;$c -lt 4 -and -not $registered;$c++){
  node "$tmp\cdp.js" $FO clickel "button[id`$=UploadControlUploadButton]" | Out-Null
  for($k=0;$k -lt 4;$k++){
    Start-Sleep -Seconds 1
    $ud = E "(()=>{const b=document.querySelector('button[id`$=UploadControlUploadButton]');return b?(b.disabled?'dis':'en'):'gone';})()"
    if($ud -match 'dis'){ $registered=$true; break }
  }
}
if(-not $registered){ node "$tmp\cdp.js" $FO clickel "button[id`$=CloseButtonAddNewTabPage]" | Out-Null; Write-Output "RESULT=FAIL_uploadclick(fn=$fn)"; exit 1 }

# wait for upload to complete: OK button becomes ENABLED (uploads can take >100s)
$ok=$false
for($i=0;$i -lt 90;$i++){
  Start-Sleep -Seconds 2
  $s = E "(()=>{const ok=document.querySelector('button[id`$=OkButtonAddNewTabPage]');const g=document.getElementById('TrvExpTrans_ReceiptsAttached_Grid_${INST}_0_${Row}_input');return (ok&&!ok.disabled?'OKEN':'okdis')+'|'+(g?g.value:'?');})()"
  if($s -match 'Yes'){ $ok=$true; break }
  if($s -match 'OKEN'){ $ok=$true; break }
}
if(-not $ok){ Write-Output "RESULT=FAIL_upload(fn=$fn)"; exit 1 }

# 6. OK loop until grid = Yes (trusted click)
$done=$false
for($i=0;$i -lt 20;$i++){
  if((E $GQ) -match 'Yes'){ $done=$true; break }
  node "$tmp\cdp.js" $FO clickel "button[id`$=OkButtonAddNewTabPage]" | Out-Null
  Start-Sleep -Seconds 2
}
if($done){ Write-Output "RESULT=Yes" } else { Write-Output "RESULT=No" }
