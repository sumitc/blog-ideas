// Render an HTML file to PDF using the already-running CDP Edge (port 9222).
// Creates a fresh tab, navigates to the file, prints to PDF, closes the tab.
// Usage: node htmlpdf.js <htmlFilePath> <pdfOutPath>
const fs = require('fs');
const http = require('http');
const htmlPath = process.argv[2];
const pdfOut = process.argv[3];
const fileUrl = 'file:///' + htmlPath.replace(/\\/g, '/');

function httpReq(path, method) {
  return new Promise((res, rej) => {
    const r = http.request({ host: 'localhost', port: 9222, path, method: method || 'GET' }, resp => {
      let d = ''; resp.on('data', c => d += c); resp.on('end', () => res(d));
    });
    r.on('error', rej); r.end();
  });
}

(async () => {
  // open a new tab (Edge requires PUT)
  const created = JSON.parse(await httpReq('/json/new?about:blank', 'PUT'));
  const targetId = created.id;
  const wsUrl = created.webSocketDebuggerUrl;
  const ws = new WebSocket(wsUrl);
  let idc = 0; const pending = {};
  function send(m, p) { return new Promise((res, rej) => { const i = ++idc; pending[i] = { res, rej }; ws.send(JSON.stringify({ id: i, method: m, params: p || {} })); }); }
  const loaded = new Promise(res => { ws.addEventListener('message', ev => { const m = JSON.parse(ev.data); if (m.method === 'Page.loadEventFired') res(); }); });
  ws.addEventListener('message', ev => { const m = JSON.parse(ev.data); if (m.id && pending[m.id]) { if (m.error) pending[m.id].rej(new Error(JSON.stringify(m.error))); else pending[m.id].res(m.result); delete pending[m.id]; } });
  await new Promise(r => ws.addEventListener('open', r));
  await send('Page.enable');
  await send('Page.navigate', { url: fileUrl });
  await Promise.race([loaded, new Promise(r => setTimeout(r, 6000))]);
  await new Promise(r => setTimeout(r, 1200)); // settle images/layout
  const r = await send('Page.printToPDF', { printBackground: true, paperWidth: 8.27, paperHeight: 11.69, marginTop: 0.4, marginBottom: 0.4, marginLeft: 0.4, marginRight: 0.4 });
  fs.writeFileSync(pdfOut, Buffer.from(r.data, 'base64'));
  ws.close();
  // close the tab
  await httpReq('/json/close/' + targetId, 'GET');
  console.log('PDF_OK', fs.statSync(pdfOut).size);
  process.exit(0);
})().catch(e => { console.log('ERR', e.message); process.exit(1); });
