param(
  [Parameter(Mandatory=$true)][int]$Row,
  [Parameter(Mandatory=$true)][string]$FileName,  # base name without extension, e.g. Uber_7-16-2026_5.95USD
  [string]$ExpectAmt = ''                          # e.g. 5.95 ; slot amount must start with this or abort
)
$ErrorActionPreference='Stop'
$tmp=$env:TEMP
$FO=$env:CDP_FO
if(-not $FO){ $FO=(Invoke-RestMethod http://localhost:9222/json/list | Where-Object {$_.type -eq 'page' -and $_.url -match 'operations\.dynamics\.com'} | Select-Object -First 1).id }
if(-not $FO){ throw 'F&O tab not found on CDP :9222 (open the expense report in the CDP-enabled Edge)' }
function E($js){ node "$tmp\cdp.js" $FO eval $js }
function C($sel){ node "$tmp\cdp.js" $FO clickel $sel | Out-Null }

$INST = (E "(()=>{const el=document.querySelector('[id*=ReceiptsAttached_Grid]');return el?el.id.match(/Grid_(\d+)_/)[1]:'0';})()").Trim('"')
$GQ = "(()=>{const g=document.getElementById('TrvExpTrans_ReceiptsAttached_Grid_${INST}_0_${Row}_input');return g?g.value:'??';})()"
if((E $GQ) -match 'Yes'){ Write-Output "RESULT=AlreadyYes"; exit 0 }

# close stray flyouts
foreach($cb in @('CloseButtonAddNewTabPage','CloseButtonExistingTabPage')){
  if((E "(()=>!!document.querySelector('button[id`$=$cb]'))()") -match 'true'){ C "button[id`$=$cb]"; Start-Sleep -Seconds 2 }
}

# select row + verify
$sel=$false
for($t=0;$t -lt 4;$t++){
  E "(()=>{const e=document.getElementById('TrvExpTrans_AmountMST_Grid_${INST}_0_${Row}_input');e.scrollIntoView({block:'center'});e.focus();e.click();return 'c';})()" | Out-Null
  Start-Sleep -Seconds 2
  $a = E "(()=>{const rows=[...document.querySelectorAll('[id^=TrvExpTrans_AmountMST_Grid_${INST}_0_][id`$=_input]')];let act='none';rows.forEach(r=>{const m=r.id.match(/_0_(\d+)_input/);const tr=r.closest('[role=row],tr,[class*=row]');if(tr&&tr.getAttribute('aria-selected')==='true')act=m[1];});return act;})()"
  if($a -match "^`"?$Row`"?$"){ $sel=$true; break }
}
if(-not $sel){ Write-Output "RESULT=FAIL_select(active=$a)"; exit 1 }

# amount guard: verify the selected slot's amount matches the intended receipt
if($ExpectAmt -ne ''){
  $slotAmt = (E "(()=>{const e=document.getElementById('AmountCurrWithCurrencyCode_Grid_${INST}_0_${Row}_input');return e?e.value:'??';})()").Trim('"')
  if($slotAmt.IndexOf($ExpectAmt) -ne 0){ Write-Output "RESULT=FAIL_amountmismatch(slot=$slotAmt expect=$ExpectAmt)"; exit 1 }
}

# open Actions -> Attach receipt
$opened=$false
for($t=0;$t -lt 4 -and -not $opened;$t++){
  C "button[id`$=CardBottomMenuFormMenuButtonControl_button]"; Start-Sleep -Seconds 2
  C "button[id`$=AttachReceiptToExpense]"; Start-Sleep -Seconds 3
  if((E "(()=>!!document.querySelector('button[id`$=UploadControlBrowseButton]'))()") -match 'true'){ $opened=$true; break }
}
if(-not $opened){ Write-Output "RESULT=FAIL_openflyout"; exit 1 }

# switch to Select existing tab
C "[id`$=ExistingTabPage_header]"; Start-Sleep -Seconds 3

# page through, find filename
$found=$false
for($pg=0;$pg -lt 12 -and -not $found;$pg++){
  $hit = E "(()=>{const ins=[...document.querySelectorAll('input[id^=Filename_]')];for(const i of ins){if((i.value||'').trim()==='$FileName'){const m=i.id.match(/Filename_(\d+)_0_(\d+)_input/);if(m)return m[1]+':'+m[2];}}return 'NO';})()"
  $hit = $hit.Trim('"')
  if($hit -ne 'NO'){
    $parts = $hit.Split(':'); $grid=$parts[0]; $idx=$parts[1]
    C "#ReceiptThumbnail_${grid}_0_${idx}"; Start-Sleep -Seconds 2
    $found=$true; break
  }
  # next page
  $nx = E "(()=>{const b=document.querySelector('button[id`$=NextPage]');return b?(b.disabled?'dis':'en'):'none';})()"
  if($nx -notmatch 'en'){ break }
  C "button[id`$=NextPage]"; Start-Sleep -Seconds 2
}
if(-not $found){ C "button[id`$=CloseButtonExistingTabPage]"; Write-Output "RESULT=FAIL_notfound"; exit 1 }

# click Add
for($i=0;$i -lt 8;$i++){
  if((E $GQ) -match 'Yes'){ break }
  C "button[id`$=AddButtonExistingTabPage]"; Start-Sleep -Seconds 3
}
if((E $GQ) -match 'Yes'){ Write-Output "RESULT=Yes" } else { Write-Output "RESULT=No" }
