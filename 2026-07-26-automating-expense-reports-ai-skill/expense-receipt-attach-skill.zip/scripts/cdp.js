// Reusable CDP driver over built-in WebSocket (Node 24+).
// Usage:
//   node cdp.js <pageId> eval "<js expression>"      -> prints JSON result of evaluating expression (awaits promises)
//   node cdp.js <pageId> shot <outfile.png>          -> screenshot
//   node cdp.js <pageId> upload "<cssSelector>" "<filepath>"  -> DOM.setFileInputFiles on matched input
//   node cdp.js <pageId> uploadNode <backendNodeId> "<filepath>"
const fs = require('fs');
const args = process.argv.slice(2);
const pageId = args[0];
const cmd = args[1];
const ws = new WebSocket('ws://localhost:9222/devtools/page/' + pageId);
let idc = 0; const pending = {};
function send(m, p) { return new Promise((res, rej) => { const i = ++idc; pending[i] = { res, rej }; ws.send(JSON.stringify({ id: i, method: m, params: p || {} })); }); }
ws.addEventListener('message', ev => { const m = JSON.parse(ev.data); if (m.id && pending[m.id]) { if (m.error) pending[m.id].rej(new Error(JSON.stringify(m.error))); else pending[m.id].res(m.result); delete pending[m.id]; } });
ws.addEventListener('error', () => { console.log('WSERR'); process.exit(1); });
function done(o) { try { console.log(typeof o === 'string' ? o : JSON.stringify(o)); } catch (e) { console.log(String(o)); } ws.close(); process.exit(0); }
ws.addEventListener('open', async () => {
  try {
    await send('Runtime.enable');
    await send('Page.enable');
    await send('DOM.enable');
    if (cmd === 'eval') {
      const expr = args[2];
      const r = await send('Runtime.evaluate', { expression: expr, returnByValue: true, awaitPromise: true, allowUnsafeEvalBlocklist: true });
      if (r.exceptionDetails) return done({ error: r.exceptionDetails.exception ? r.exceptionDetails.exception.description : r.exceptionDetails.text });
      return done(r.result.value === undefined ? { ok: true } : r.result.value);
    }
    if (cmd === 'shot') {
      const r = await send('Page.captureScreenshot', { format: 'png' });
      fs.writeFileSync(args[2], Buffer.from(r.data, 'base64'));
      return done('OK');
    }
    if (cmd === 'upload') {
      const sel = args[2]; const file = args[3];
      const ev = await send('Runtime.evaluate', { expression: `document.querySelector(${JSON.stringify(sel)})`, });
      if (!ev.result || !ev.result.objectId) return done({ error: 'input not found for ' + sel });
      await send('DOM.setFileInputFiles', { files: [file], objectId: ev.result.objectId });
      return done('UPLOADED');
    }
    if (cmd === 'browse') {
      // args[2] = css selector of Browse button, args[3] = file path
      const sel = args[2]; const file = args[3];
      let chooserNode = null;
      const gotChooser = new Promise(res => {
        ws.addEventListener('message', ev => { const m = JSON.parse(ev.data); if (m.method === 'Page.fileChooserOpened') { chooserNode = m.params.backendNodeId; res(); } });
      });
      const rectR = await send('Runtime.evaluate', { expression: `(()=>{const e=document.querySelector(${JSON.stringify(sel)});if(!e)return null;const r=e.getBoundingClientRect();return {x:r.left+r.width/2,y:r.top+r.height/2};})()`, returnByValue: true });
      const rect = rectR.result.value;
      if (!rect) return done({ error: 'browse btn not found' });
      await send('Page.setInterceptFileChooserDialog', { enabled: true });
      await send('Input.dispatchMouseEvent', { type: 'mousePressed', x: rect.x, y: rect.y, button: 'left', clickCount: 1 });
      await send('Input.dispatchMouseEvent', { type: 'mouseReleased', x: rect.x, y: rect.y, button: 'left', clickCount: 1 });
      await Promise.race([gotChooser, new Promise(r => setTimeout(r, 6000))]);
      if (chooserNode == null) { await send('Page.setInterceptFileChooserDialog', { enabled: false }); return done({ error: 'no fileChooser event' }); }
      await send('DOM.setFileInputFiles', { files: [file], backendNodeId: chooserNode });
      await send('Page.setInterceptFileChooserDialog', { enabled: false });
      return done('BROWSED');
    }
    if (cmd === 'clickel' || cmd === 'clicktext') {
      let expr;
      if (cmd === 'clickel') {
        expr = `(()=>{const e=document.querySelector(${JSON.stringify(args[2])});if(!e)return null;e.scrollIntoView({block:'center'});const r=e.getBoundingClientRect();return {x:r.left+r.width/2,y:r.top+r.height/2};})()`;
      } else {
        const txt = args[2];
        expr = `(()=>{const els=[...document.querySelectorAll('button,[role=menuitem],span,div,a,input')].filter(e=>((e.innerText||e.value||'').trim())===${JSON.stringify(txt)});const e=els[0];if(!e)return null;e.scrollIntoView({block:'center'});const r=e.getBoundingClientRect();return {x:r.left+r.width/2,y:r.top+r.height/2};})()`;
      }
      const rr = await send('Runtime.evaluate', { expression: expr, returnByValue: true });
      const p = rr.result.value;
      if (!p) return done({ error: 'element not found' });
      await send('Input.dispatchMouseEvent', { type: 'mouseMoved', x: p.x, y: p.y });
      await send('Input.dispatchMouseEvent', { type: 'mousePressed', x: p.x, y: p.y, button: 'left', clickCount: 1 });
      await send('Input.dispatchMouseEvent', { type: 'mouseReleased', x: p.x, y: p.y, button: 'left', clickCount: 1 });
      return done({ clicked: true, x: p.x, y: p.y });
    }
    if (cmd === 'uploadNode') {
      const backendNodeId = parseInt(args[2], 10); const file = args[3];
      await send('DOM.setFileInputFiles', { files: [file], backendNodeId });
      return done('UPLOADED');
    }
    if (cmd === 'type') {
      // type <selector> <text> : click element, then insert text
      const sel = args[2]; const text = args[3];
      await send('Runtime.evaluate', { expression: `(()=>{const e=document.querySelector(${JSON.stringify(sel)});if(e)e.scrollIntoView({block:'center'});return 1;})()`, returnByValue: true });
      await new Promise(r => setTimeout(r, 400));
      const rr = await send('Runtime.evaluate', { expression: `(()=>{const e=document.querySelector(${JSON.stringify(sel)});if(!e)return null;const r=e.getBoundingClientRect();return {x:r.left+r.width/2,y:r.top+r.height/2};})()`, returnByValue: true });
      const p = rr.result.value;
      if (!p) return done({ error: 'type target not found' });
      // triple-click to focus + select-all existing content within the field
      await send('Input.dispatchMouseEvent', { type: 'mousePressed', x: p.x, y: p.y, button: 'left', clickCount: 1 });
      await send('Input.dispatchMouseEvent', { type: 'mouseReleased', x: p.x, y: p.y, button: 'left', clickCount: 1 });
      await send('Input.dispatchMouseEvent', { type: 'mousePressed', x: p.x, y: p.y, button: 'left', clickCount: 2 });
      await send('Input.dispatchMouseEvent', { type: 'mouseReleased', x: p.x, y: p.y, button: 'left', clickCount: 2 });
      await send('Input.dispatchMouseEvent', { type: 'mousePressed', x: p.x, y: p.y, button: 'left', clickCount: 3 });
      await send('Input.dispatchMouseEvent', { type: 'mouseReleased', x: p.x, y: p.y, button: 'left', clickCount: 3 });
      await new Promise(r => setTimeout(r, 200));
      await send('Input.dispatchKeyEvent', { type: 'keyDown', key: 'Delete', code: 'Delete', windowsVirtualKeyCode: 46 });
      await send('Input.dispatchKeyEvent', { type: 'keyUp', key: 'Delete', code: 'Delete', windowsVirtualKeyCode: 46 });
      await new Promise(r => setTimeout(r, 150));
      await send('Input.insertText', { text });
      await new Promise(r => setTimeout(r, 150));
      return done({ typed: text });
    }
    if (cmd === 'press') {
      // press <keyName> e.g. Enter
      const key = args[2] || 'Enter';
      const map = { Enter: { key: 'Enter', code: 'Enter', windowsVirtualKeyCode: 13 }, Escape: { key: 'Escape', code: 'Escape', windowsVirtualKeyCode: 27 }, Tab: { key: 'Tab', code: 'Tab', windowsVirtualKeyCode: 9 }, ArrowDown: { key: 'ArrowDown', code: 'ArrowDown', windowsVirtualKeyCode: 40 }, ArrowUp: { key: 'ArrowUp', code: 'ArrowUp', windowsVirtualKeyCode: 38 }, PageDown: { key: 'PageDown', code: 'PageDown', windowsVirtualKeyCode: 34 }, PageUp: { key: 'PageUp', code: 'PageUp', windowsVirtualKeyCode: 33 }, End: { key: 'End', code: 'End', windowsVirtualKeyCode: 35 }, Home: { key: 'Home', code: 'Home', windowsVirtualKeyCode: 36 } };
      const k = map[key] || map.Enter;
      await send('Input.dispatchKeyEvent', { type: 'keyDown', ...k });
      await send('Input.dispatchKeyEvent', { type: 'keyUp', ...k });
      return done({ pressed: key });
    }
    if (cmd === 'nav') {
      const url = args[2];
      const loaded = new Promise(res => { ws.addEventListener('message', ev => { const m = JSON.parse(ev.data); if (m.method === 'Page.loadEventFired') res(); }); });
      await send('Page.navigate', { url });
      await Promise.race([loaded, new Promise(r => setTimeout(r, 12000))]);
      return done('NAV_OK');
    }
    if (cmd === 'wheel') {
      const sel = args[2]; const dy = parseInt(args[3], 10) || -600;
      const rr = await send('Runtime.evaluate', { expression: `(()=>{const e=document.querySelector(${JSON.stringify(sel)});if(!e)return null;const r=e.getBoundingClientRect();return {x:r.left+r.width/2,y:r.top+r.height/2};})()`, returnByValue: true });
      const p = rr.result.value;
      if (!p) return done({ error: 'wheel target not found' });
      await send('Input.dispatchMouseEvent', { type: 'mouseWheel', x: p.x, y: p.y, deltaX: 0, deltaY: dy });
      return done({ wheeled: true, dy });
    }
    return done({ error: 'unknown cmd ' + cmd });
  } catch (e) { return done({ error: e.message }); }
});
setTimeout(() => { console.log('TIMEOUT'); process.exit(1); }, 25000);
