param(
  [string]$Text = "bill misplaced",
  [string]$OutPdf = "$env:TEMP\bill-misplaced.pdf"
)
# LAST-RESORT ONLY. Generates a plain placeholder PDF to attach to an expense line
# that has NO real receipt available. Use strictly when the user explicitly directs it.
$ErrorActionPreference='Stop'
$py = @"
import fitz
doc=fitz.open()
page=doc.new_page(width=612,height=792)
page.draw_rect(fitz.Rect(0,0,612,792),color=(0.85,0.85,0.85),fill=(1,1,1))
page.insert_textbox(fitz.Rect(56,340,556,452),r'''$Text''',fontsize=40,fontname='helv',color=(0.4,0.4,0.4),align=1)
doc.save(r'''$OutPdf''')
print('saved '+r'''$OutPdf''')
"@
$py | python -
