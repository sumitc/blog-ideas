---
name: expense-receipt-attach
description: Attach receipt bills to each line of a Microsoft Dynamics 365 Finance & Operations (F&O) expense report, matching each receipt to a line by exact amount + date. Drives the F&O web UI over CDP on an existing Edge session (port 9222), pulls receipts from an Outlook web tab and/or local PDFs, fills required Business Purpose fields, and verifies every line turns green. Use when the user asks to attach/upload receipts, invoices, or bills to an expense report, reconcile a trip's expenses, or "make the lines green".
metadata:
  author: sumitc
  version: "1.1.0"
---

# Expense Receipt Attach (Dynamics F&O)

Attach receipts to expense-report lines in Microsoft Dynamics 365 F&O by driving the
web UI through Chrome DevTools Protocol (CDP) against an already-open, authenticated
Edge browser. Receipts come from an Outlook web tab (email search) and/or local PDFs.
**Matching rule: exact charged amount + date per line.**

## When to use
- "Attach the receipts to my expense report", "upload bills for the Redmond trip"
- "Find the Uber/airfare/hotel receipt in my email and attach it"
- "Read this receipts PDF and attach each page to the matching line"
- "Make the remaining lines green"

## Setup — opening the report (do this first, don't assume it's done)
The person who built this skill usually opened the expense report themselves and handed it
off. **Do not assume that has happened.** At the start of every run, confirm the CDP session
and that the specific draft report is open on screen; if not, walk the user through it. Auth
(SSO/MFA) must be done by the user in their own signed-in Edge — never try to log in for them.

**Step 0 — Is CDP already up with the report open?**
```powershell
try { $t = Invoke-RestMethod http://localhost:9222/json/list -TimeoutSec 3 } catch { $t = $null }
if(-not $t){ "CDP NOT running on :9222" }
else {
  $fo = $t | Where-Object { $_.type -eq 'page' -and $_.url -match 'operations\.dynamics\.com' }
  $ol = $t | Where-Object { $_.type -eq 'page' -and $_.url -match 'outlook\.office' }
  "F&O tab: "     + ($(if($fo){'YES'}else{'NO'}))
  "Outlook tab: " + ($(if($ol){'YES'}else{'NO'}))
}
```

**Step 1 — If CDP is NOT running:** ask the user to launch Edge with debugging enabled
(this reuses their existing signed-in profile so they stay authenticated):
```powershell
# Close existing Edge windows first, then:
& "$env:ProgramFiles (x86)\Microsoft\Edge\Application\msedge.exe" --remote-debugging-port=9222 --profile-directory="Default"
# (path may be "%ProgramFiles%\Microsoft\Edge\Application\msedge.exe" on some machines)
```
Then re-run Step 0 until it reports CDP up.

**Step 2 — If the F&O tab is missing or not on the report:** ask the user for their
expense-report/workspace URL (it looks like
`https://<tenant>.operations.dynamics.com/?cmp=<co>&mi=ExpenseWorkspace`), then navigate the
CDP tab and have the user click into the specific **draft** report:
```powershell
$FO = ($t | ? {$_.type -eq 'page'} | Select-Object -First 1).id
node scripts\cdp.js $FO nav "https://<tenant>.operations.dynamics.com/?cmp=<co>&mi=ExpenseWorkspace"
```
The report is ready when the grid `[id*=ReceiptsAttached_Grid]` exists (poll for it; the
workspace shows a loading spinner first, ~15-30s). **Prefer letting the user click into the
report** — the workspace list row sometimes needs two clicks and MFA may interrupt.

**Step 3 — If email receipts are needed:** ask the user to open Outlook web
(`https://outlook.office.com/mail/`) in another tab of the same CDP Edge, signed in.

Only proceed to the matching/upload workflow once Step 0 reports **F&O tab: YES** and the grid
is present. Confirm the report name/trip with the user before attaching anything.

## Prerequisites
- **Edge running with CDP**: launched with `--remote-debugging-port=9222` (see Setup above). Verify:
  `Invoke-RestMethod http://localhost:9222/json/list` returns page targets.
- The **F&O expense report** open in one tab (URL contains `operations.dynamics.com`)
  and drilled into the specific draft report (grid `[id*=ReceiptsAttached_Grid]` present).
- Optional **Outlook web** open in another tab (URL contains `outlook.office`) for email receipts.
- **Node.js** (global `WebSocket`) and **Python** with `pymupdf` (`pip install pymupdf`) for reading/rendering PDFs.
- Scripts auto-discover the tabs by URL. Override with env vars `CDP_FO` / `CDP_OL` if needed.

## Core tools (in `scripts/`)
| Script | Purpose |
|--------|---------|
| `cdp.js` | CDP driver. `node cdp.js <target> <cmd> …`. Commands: `eval <js>`, `shot <file>`, `browse <sel> <file>` (trusted file-chooser upload), `clickel <sel>`, `clicktext <t>`, `type <sel> <text>` (triple-click select + insertText), `press <Enter\|Escape\|Tab\|ArrowDown\|ArrowUp\|PageDown\|PageUp\|Home\|End>`, `wheel <sel> <dy>`, `nav <url>`. |
| `attachbill.ps1` | **Primary.** Upload+attach a PDF to a line. `-Row <slot> -Pdf <path> -AmtTag <substr> [-ExpectAmt <amt>]`. Auto-detects grid instance; selects row with amount guard; Actions→Attach→browse→Upload→OK-loop until grid=Yes. Prints `RESULT=Yes\|FAIL_*`. |
| `attachexisting.ps1` | Link an already-server-side receipt by filename via the "Select existing" tab. `-Row <slot> -FileName <base> [-ExpectAmt]`. Reliable fallback when upload hangs. |
| `fillpurpose.ps1` | Fill the required "Expense Description / Business Purpose" on an invalid line so Attach becomes available / the line turns green. `-Amt <amt> -Text <text>`. |
| `getuber.ps1` | Fetch an emailed receipt from the Outlook tab (search → pick → extract `[id^=UniqueMessageBody]` → render to PDF). Pattern is reusable for any vendor. |
| `htmlpdf.js` | Render an HTML file → PDF via a fresh CDP tab + `Page.printToPDF`. |
| `make-placeholder.ps1` | **Last resort only.** Generate a "bill misplaced" placeholder PDF. See guardrail below. |

## Workflow

### 1. Connect & enumerate lines
```powershell
Invoke-RestMethod http://localhost:9222/json/list   # confirm F&O + Outlook tabs
```
Dump every line's amount + receipt status (re-detect instance every time):
```js
(()=>{const inst=document.querySelector('[id*=ReceiptsAttached_Grid]').id.match(/Grid_(\d+)_/)[1];
const amts=[...document.querySelectorAll('input[id*=AmountCurrWithCurrencyCode_Grid_'+inst+'_0_]')];
return JSON.stringify(amts.map(a=>{const r=a.id.match(/_0_(\d+)_input/)[1];
const g=document.getElementById('TrvExpTrans_ReceiptsAttached_Grid_'+inst+'_0_'+r+'_input');
return {r,amt:a.value,rcpt:g?g.value:'?'};}));})()
```

### 2. Gather receipts and match by amount + date
- **Email**: use `getuber.ps1` (or its pattern) against the Outlook tab. Search box is
  `#topSearchInput`; **clear it first** (see gotcha) then `type` + `press Enter`.
- **Local PDF**: read text with pymupdf. If pages are scanned images (empty text),
  render to PNG (`page.get_pixmap(dpi=130)`) and read visually. Record each page's date + Total,
  then map only pages whose (date, amount) exactly match an unattached line.
- Confirm the receipt's amount/date match the line **before** attaching. One invoice can
  cover several lines (e.g. an airfare invoice → ticket + fee + GST lines).

### 3. Fill required Business Purpose (if needed), then attach
A newly-added line with an empty "Expense Description / Business Purpose" is invalid
("Please enter all required fields to continue") and its **Attach action is disabled**.
Fill it first, then attach:
```powershell
.\fillpurpose.ps1 -Amt "19.95" -Text "Ground transportation - <trip> business trip"
.\attachbill.ps1  -Row 24 -Pdf "C:\path\receipt.pdf" -AmtTag "receipt" -ExpectAmt "19.95"
```

### 4. Verify
Re-scan (step 1) — every intended line shows `rcpt=Yes`. Select a line and screenshot the
detail pane to confirm the **green check** (no red X). The red X in the grid's left column is a
**validation** flag (usually missing Business Purpose), *not* the receipt column.

## Critical gotchas (learned the hard way)
- **Grid is virtualized & re-sorts.** The DOM slot index (`Grid_<INST>_0_<r>_input`) is a
  render-buffer slot, **not** a stable row id — the same slot shows different data after
  scrolling/re-sort. **Always locate the target by matching the amount immediately before
  acting**, and pass `-ExpectAmt` as a guard.
- **Only buffered rows exist in the DOM.** To reach an off-screen line, focus a visible
  row cell and `press PageUp/PageDown` (CDP wheel and synthetic WheelEvents do **not** move
  this React fixed-data-table). Then re-query.
- **Grid instance (`$INST`) changes on every reload** (e.g. 168↔152). Auto-detect it from
  `[id*=ReceiptsAttached_Grid]` every time (scripts already do).
- **Detail-pane prefix changes** (`ExpenseReportDetails_2`/`_3`). Use suffix selectors:
  `id$=AdditionalInformation_textArea`, `id$=CommandButtonNext` (Save and continue), `id$=EditReceipts`.
- **`ShellBlockingDiv` overlay** (z-index 1100) covers the page during async ops and can get
  **stuck**, silently swallowing all clicks/keystrokes. Poll it clear before every interaction:
  `(()=>{const b=document.getElementById('ShellBlockingDiv');return b?(b.offsetParent!==null?'BLOCK':'clear'):'clear';})()`.
  If stuck >30s, `location.reload()` and re-open the report.
- **Programmatic value-setting fails** on Dynamics inputs (native setter + input/change leaves
  the model unchanged; validation still fails). Use **real CDP keystrokes** — `type` uses
  triple-click to select (Ctrl+A is hijacked by the grid) then `Input.insertText`.
- **Upload endpoint intermittently hangs** (`FAIL_upload`) but often still uploads the file
  server-side as an orphan. On a clean page (overlay clear, required fields filled) it usually
  succeeds first try. Fallback: `attachexisting.ps1` to link the orphaned file by name.
- **Reopening after reload**: you land on the Expense-management workspace list; click the
  report number, wait ~15-30s for `[id*=ReceiptsAttached_Grid]`.
- **Outlook search box appends, doesn't replace** — clear it first:
  `(()=>{const s=document.querySelector('#topSearchInput');s.focus();const set=Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype,'value').set;set.call(s,'');s.dispatchEvent(new Event('input',{bubbles:true}));})()`
  then `type` the query and `press Enter`.
- **Timezone/sync**: when matching by date, also try ±1 day.
- **mail MCP may be down** — prefer the authenticated Outlook CDP tab.

## Placeholder guardrail (STRICT)
`make-placeholder.ps1` creates a "bill misplaced" PDF to attach when a line has **no real
receipt anywhere**. This is a **last resort only**, and must be **explicitly directed by the
user each time** — never apply it automatically. Attach it exactly like a real receipt, then
fill the Business Purpose so the line turns green:
```powershell
.\make-placeholder.ps1 -OutPdf "$env:TEMP\bill-misplaced.pdf"
.\attachbill.ps1  -Row 29 -Pdf "$env:TEMP\bill-misplaced.pdf" -AmtTag "bill-misplaced" -ExpectAmt "1.50"
.\fillpurpose.ps1 -Amt "1.50" -Text "Meals - <trip> business trip"
```

## Definition of done
Every intended line has `rcpt=Yes` and a green check (no red X), the top yellow "missing
required information" banner is gone, and the report's Receipts count reflects the additions.
Report any line left without a receipt (no matching bill found) so the user can decide.
